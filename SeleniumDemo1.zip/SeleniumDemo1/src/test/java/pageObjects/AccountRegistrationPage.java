package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class AccountRegistrationPage extends BasePage {

	
	//constructor
		public AccountRegistrationPage(WebDriver driver) {

			super(driver);
		}
   //locators
		@FindBy(xpath = "//input[@id=\"input-firstname\"]")
		WebElement txt_firstname;
		
		@FindBy(xpath = "//input[@id=\"input-lastname\"]")
		WebElement txt_lastname;
		
		@FindBy(xpath = "//input[@id=\"input-email\"]")
		WebElement txtEmail;


	@FindBy(xpath = "//input[@id='input-telephone']")
	WebElement txtTelephone;


	@FindBy(xpath = "//input[@id=\"input-password\"]")
	WebElement txtPassword;

	@FindBy(xpath = "//input[@id=\"input-confirm\"]")
	WebElement txtConfirmPassword;

//change the xpath
	@FindBy(xpath = "//input[@name=\"agree\"]")
	WebElement chkdPolicy;
		

		
		@FindBy(xpath = "//input[@type='submit']")
		WebElement btn_continue;

	@FindBy(xpath = "//h1[normalize-space()='Your Account Has Been Created!']")
	WebElement getConfirmation;

   //actions
		public void setFirstname(String fname){

			txt_firstname.sendKeys(fname);
		}
		public void setLastname(String lname) {
			txt_lastname.sendKeys(lname);
		}
		public void setEmail(String email)
		{

			txtEmail.sendKeys(email);
		}
		public void setTelephone(String tel)
		{
           txtTelephone.sendKeys(tel);
		}

	public void setPassword(String pwd)
	{
		txtPassword.sendKeys(pwd);

	}


	public void setConfirmPassword(String pwd)
		{

			txtConfirmPassword.sendKeys(pwd);
		}

		public void setPrivacyPolicy()
		{

			chkdPolicy.click();
		}

		public void clickContinue()
		{

			btn_continue.click();
		}
		public String getConfirmationMsg()
		{
			try{
				return (getConfirmation.getText());
			}catch (Exception e)
			{
				return (e.getMessage());
			}
		}
}
