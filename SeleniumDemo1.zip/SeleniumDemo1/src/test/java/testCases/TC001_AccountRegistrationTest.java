package testCases;

import org.openqa.selenium.WebDriver;

import org.testng.Assert;
import org.testng.annotations.Test;
import pageObjects.AccountRegistrationPage;
import pageObjects.HomePage;
import testBase.BaseClass;
//one class - one test case
public class TC001_AccountRegistrationTest extends BaseClass {
	@Test(groups = {"Regression","Master"})

	public void verify_account_registration() {
		logger.info("*********  Starting TC001_AccountRegistrationTest  ******");
try{
		HomePage hm = new HomePage(driver);
		hm.clickMyAccount();
		hm.clickRegister();

		AccountRegistrationPage regPage = new AccountRegistrationPage(driver);
		regPage.setFirstname(randomeString().toUpperCase()); //string
		regPage.setLastname(randomeString().toUpperCase()); //string
		regPage.setEmail(randomeString() + "@gmail.com"); //string
		regPage.setTelephone(randomeNumber()); //number

		String password = randomeAlphanumeric();//store first
	System.out.println("Generated password = " + password);
		regPage.setPassword(password); //alphanumeric
		regPage.setConfirmPassword(password);

		regPage.setPrivacyPolicy();
		regPage.clickContinue();

		logger.info("validating expected message");
	String confmsg = regPage.getConfirmationMsg();
	System.out.println("Confirmation message = [" + confmsg + "]");
		if(confmsg.equals("Your Account Has Been Created!"))
		{
			Assert.assertTrue(true);
		}
		else {
			logger.error("Test failed...");
			logger.debug("Debug logs..");
			Assert.assertTrue(false);
		}

//		Assert.assertEquals(confmsg, "Your Account Has Been Created!");
	}catch (Exception e)
{
	Assert.fail();
}
logger.info("********Finished TC001_AccountRegistrationTest  ******");

	}


	}

