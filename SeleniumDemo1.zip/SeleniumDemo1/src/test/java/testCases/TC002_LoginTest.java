package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;
import pageObjects.HomePage;
import pageObjects.LoginPage;
import pageObjects.MyAccountPage;
import testBase.BaseClass;

public class TC002_LoginTest extends BaseClass {

    @Test(groups = {"sanity","Master"})
    public void verify_login()
    {
   logger.info("***Starting TC002_Login Test******");
try {
    //homepage
    HomePage hm = new HomePage(driver);
    hm.clickMyAccount();
    hm.clickLogin();
    //login page
    LoginPage lp = new LoginPage(driver);
    lp.setEmail(p.getProperty("email"));
    lp.setPassword(p.getProperty("password"));
    lp.clickLogin();

    //My ACcount page
    MyAccountPage macc = new MyAccountPage(driver);
    boolean targetPage = macc.isMyAccountPageExist();

//        Assert.assertTrue(targetPage);
    Assert.assertEquals(targetPage, true, "Login Failed");

    //logout
    macc.clickLogout();
}catch (Exception e){
    Assert.fail();
}
        logger.info("*****Finished TC_002_LoginTest****");
    }
}
